Trials and discoveries

2018-02-14
These two files
.\ch\navimapdata.bin
.\in\navimapdata.bin

seem to have an 8 byte header
if you 00 out the rest of the file (in hex) and re-inject back to VBF. then party+party gambits become available in all areas.

currently unknown effects on game.

experiments conducted by discord users
@ejh1990#1130 
@Davoodinator#6875 

nexusmod link to download w/instructions (might not be approved yet):
https://www.nexusmods.com/mods/1?game_id=2304